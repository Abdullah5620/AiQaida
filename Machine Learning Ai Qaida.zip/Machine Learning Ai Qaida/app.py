import os
import torch
from torch.serialization import add_safe_globals
from TTS.tts.configs.xtts_config import XttsConfig

# Allow XTTS config to unpickle under torch>=2.6
add_safe_globals([XttsConfig])

from flask import Flask, render_template, send_file, request, jsonify
import librosa
import numpy as np
import soundfile as sf
from TTS.api import TTS

# ── Paths & Flask setup ───────────────────────────────────
BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
REF_PATH  = os.path.join(BASE_DIR, 'models', 'XTTS-v2', 'reference.wav')
AUDIO_DIR = os.path.join(BASE_DIR, 'static', 'audio')
os.makedirs(AUDIO_DIR, exist_ok=True)

app = Flask(__name__, template_folder='templates')

# ── Initialize TTS once ────────────────────────────────────
tts = TTS(
    model_name="tts_models/multilingual/multi-dataset/xtts_v2",
    gpu=False, progress_bar=False
)

# ── Pre-generate feedback templates ────────────────────────
feedback_templates = {
    'high':   "بہت خوب",
    'medium': "بہتر کریں",
    'low':    "دوبارہ کریں"
}
for key, text in feedback_templates.items():
    out = os.path.join(AUDIO_DIR, f"feedback_{key}.wav")
    if not os.path.isfile(out):
        wav = tts.tts(text=text, language="ar", speaker_wav=REF_PATH)
        sr  = tts.synthesizer.tts_config["audio"]["output_sample_rate"]
        sf.write(out, wav, sr)

# ── Data Definitions ────────────────────────────────────────
letters = [
    ("ا","أَلِف"), ("ب","بَاء"), ("ت","تَاء"), ("ث","ثَاء"),
    ("ج","جِيم"), ("ح","حَاء"), ("خ","خَاء"), ("د","دَال"),
    ("ذ","ذَال"), ("ر","رَاء"), ("ز","زَاي"), ("س","سِين"),
    ("ش","شِين"), ("ص","صَاد"), ("ض","ضَاد"), ("ط","طَاء"),
    ("ظ","ظَاء"), ("ع","عَيْن"), ("غ","غَيْن"), ("ف","فَاء"),
    ("ق","قَاف"), ("ك","كَاف"), ("ل","لَام"), ("م","مِيم"),
    ("ن","نُون"), ("ه","هَاء"), ("و","وَاو"), ("ي","يَاء")
]

fathah_words = [(w, w) for w in [
    "أَخَذَ","بَعَثَ","ذَرَا","سَالَ","بَدَأَ","وَجَدَ",
    "ذَهَبَ","صَبَرَ","تَرَكَ","حَمَلَ","سَكَتَ","فَتَحَ",
    "مَثَلَ","شَرَحَ","خَتَمَ","وَنَفَخَ","عَزَمَ","نَظَرَ",
    "ظَلَمَ","جَعَلَ","عَبَدَ","أَفَلَ","غَفَرَ","صَرَفَ"
]]

kasra_words = [(w, w) for w in [
    "رِمْ", "خِبَط", "بِ", "أَتْ", "تِ", "وَرْدَة", "رِ", "تَجَد",
    "جِ", "رَحِمْ", "بِخَل", "رِدْف", "أُذُن", "زِ", "أَثَر", "فَقِرَ",
    "خِسِر", "شِيْع", "شِ", "رِضِي", "ضِ", "خِطْف", "طِ", "عِوَج",
    "حِفْظ", "فِ", "مَلِك", "عِلْم", "أَمِن", "تَرَن", "شَهِد", "يَدِي"
]]

dammah_words = [(w, w) for w in [
    "اُفْك", "بُ", "تُصُف", "ثُ", "جُ", "حُشْر", "خُمْسَة", "دُبْرَة",
    "أُذُن", "أَتْدُر", "زُبْرَ", "رُسُل", "شُعْبَة", "صُحُف", "ضُرُب",
    "طُرُوف", "ظُلْمٌ", "عُدُّ", "غُلبَت", "فُطْع", "قُ", "كُبْتٌ",
    "لُعْنَة", "مُحَمَّدٌ", "نُشُورٌ", "هُوَ", "وُعُودٌ", "يُرُدُ"
]]

# Jazm or Sukoon words
jazm_or_sukoon_words = [
    ("غْ", "تَنَغْ"),
    ("أفصح", "أَفْصَح"),
    ("عْدْت", "عَدْت"),
    ("فأجرة", "فَأْجُرَة"),
    ("تقهر", "تَقْهَر"),
    ("تقْل", "تَقْل"),
    ("ترجع", "تَرْجِع"),
    ("تسطع", "تَسْطَع"),
    ("تكْرَه", "تَكْرَه"),
    ("خلق", "خَلْقٌ"),
    ("تصبْر", "تَصْبِر"),
    ("أشهد", "أَشْهَد")
]

# ——— Madd Letter Alif ———
Madd_Letter_Alif_words = [(w, w) for w in [
    'كَانَ','إِذَا','رَأَى','تَابَ','لَنَا','لَهَا',
    'قَالَ','تَبَارَكَ','خَادِعُهُمْ','دَابِر','طَائِرُهُمْ','فَاتَكُمْ',
    'ضَاقَتْ','مَهْمَا','ظَاهِر','سَأَلَتْ','زَالَتْنَا','أَبِي',
    'عَالِمٌ','ثَالِثُ','رَابِعُهُمْ','يُجَاهِدُ','أَعْطَى','لَا مَسْتَمْ',
    'شَائِتُكَ','هَوَى','أَعْطَيْنَاكَ','مَالِكَ','صَاحِبُهُ','وَالْفِيَا',
    'فَسْقَى','مَغَانِم','غَالِب','طَعَام','آدَم','وَأَصْلَحَا',
]]

# ——— Madd Letter Yaa ———
Madd_Letter_Yaa_words = [(w, w) for w in [
    'ميراث','غيض','نجاري','يجيرني','يريد','يحييكم','نفسي','يهيج',
    'أجيب','جيدها','مخلصين','تثير','قيل','شيعته','فيها','وتشتكي',
    'لي','عيسى','يعطيك','رسلي',
    'إناء','بي','سبيل','حين','ويهدي','أخي','نصيح','إيلاف',
    'حديث','دين','أرضي','يأتكم',
]]

# ——— Madd Letter Waaw (و) ———
Madd_Letter_Waaw_words = [(w, w) for w in [
    'ويحفظوا', 'ويدعون', 'طوبي', 'نخوض',
    'نور',      'يكذبون', 'وأوفوا', 'قالوا',
    'هود',      'سوء',      'ينقصوا',  'يعقوب',
    'يوسف',     'شورى',     'خذوا',    'داود',
    'أوحى',     'دونه',     'ويلعبوا', 'تبعثون',
    'فتحوا',    'تعودون',  'لبثوا',   'ويرجووا',
    'موسى',     'روحه',     'ويبعثون','أشكوا',
]]

# ——— Tanwīn (ًٌٍ) ———
Tanveen_words = [(w, w) for w in [
    'نَبَاتًا',  'حَاسِدٍ',   'شَيئٍ',    'مَوْجٍ',
    'ثَلَاثَةٍ', 'يَوْمَئِذٍ', 'خَشَبٍ',   'لَهَبٍ',
    'حَدِيثًا', 'أَحَدًا',   'أُخْتٍ',    'نُوحٍ',

    'صَالِحًا', 'يُسْرًا',   'مُؤْسَدَةٍ','لَوْحٍ',
    'خَوْفٍ',   'صُحُفًا',   'وَحْشٍ',    'رَجْزٍ',
    'فَلَكٍ',   'لَيْلًا',   'بَصِيرٍ',   'صِرَاطٍ',

    'ضِلَالٍ',  'قَوْمًا',   'عَزِيزٍ',   'قُرَيْشٍ',
    'مُبِينٍ',  'مَسْكِينًا','قَصَصًا',   'وَنَقْصٍ',
    'سَمِيعٍ',  'خُبْرًا',   'عَرْشٍ',    'مُبَارَكٍ',
]]

# ——— Shadda Words ———
Shadda_words = [(w, w) for w in [

    "يَبَّثَ", "يَتَّبِعَ",
    "رَبَّكَ", "لَحَّبَ",
    "شَرَّ",   "حَقَّ",
    "تَنَزَّلَ","فَصَّلَ",
    "خَفَّتَ","وَتَوَكَّلَ",
    "سَنُشَّدُ","ثُمَّ",
    "يَمَسُّهُمْ","وَبَشِّرْ",
    "حَجِّ",     "وَطَهِّرْكَ",
    "يَقُصُّ",  "تَطَلَّعْ",
    "حَرَّمَ",  "سَوَّلَتْ",
    "شَحَّ",    "وَنَفَضَّلَ",
    "يَظَنُّ",  "تَبَيَّنَ",

    # last two
    "كَذَّبَ", "يَعْظَمُ",
]]

# ——— Moon & Sun Letters ———
Moon_And_Sun_Lee_words = [(w, w) for w in [
    'الجبال', 'القمر', 'العابدون', 'الكبير',
    'الباري',  'الماء',  'القادر',   'الواحد',
    'الغار',   'الخالق','اليتيم',   'الورد',
    'الضعفاء','الشمس','الصبح',  'الطفل',
    'الرحمان','السبل','الثُلث',  'الربا',
    'التجارة','الدعاء','الشتاء',  'الزراعون',
    'الذهب',   'النساء','اللّطيف','الظالم',
]]

# ——— Lafẓatullāh Words ———
Lafzatullah_words = [(w, w) for w in [
    'اللَّهُمَّ',     # top-left
    'اللَّهُ',       # top-right
    'إِنَّ اللَّهَ',  # 2nd row left
    'وَاللَّهِ',     # 2nd row right
    'فَضْلُ اللَّهِ', # 3rd row left
    'سُبْحَانَكَ اللَّهُمَّ', # 3rd row right
    'قُلِ اللَّهَ',   # 4th row left
    'قَالُوا اللَّهُمَّ',   # 4th row right
    'فَاللَّهُ',     # 5th row left
    'لِلَّهِ',       # 5th row middle
    'قُلِ اللَّهُمَّ',# 6th row (full‐width)
]]

Al_Madd_al_Tabee_words = [(w, w) for w in [
    "تَهْدِي", 
    "ظَلَمُوا", 
    "قَادِرُونَ عَلَيْهَا", 
    "نُوحِيهَا", 
    "ذُوقُوا", 
    "حُسْنَى", 
    "يَقُولُ", 
    "سَبْعِينَ", 
    "طٰه", 
    "صَالِحِينَ", 
    "لِحَافِظُونَ", 
    "سَمِحُوا", 
]]

Madd_Al_Muttasil_words = [(w, w) for w in [
    "شَيْء",
    "سَوْء", 
    "إِذَا جَاءَ", 
    "الْمَلَائِكَةُ", 
    "وَالسَّمَاءِ", 
    "وَشُرَكَاؤُكُمْ", 
    "كَبَائِرَ", 
    "سَوَاءٌ عَلَيْهِمْ", 
    "أَمْوَالَهُمْ رِئَاءَ النَّاسِ", 
    "إِيَّاكَ", 
    "قَائِمَةٌ", 
    "يُنَزِّلُ الْمَلَائِكَةَ", 
]]

Madd_Al_Munfasil_words = [(w, w) for w in [
    "قَالُوا أَخَافُ",
    "أُنزِلَ بِمَا آمَنَا",
    "مَا أَلْفَيْنَا",
    "إِنِّي إِذًا",
    "عَسَى أَلَّا",
    "نُوحِيَ إِلَيْهِمْ",
    "يَا أَيُّهَا",
    "إِنَّ مَالَهُ أَخْلَدَهُ",
    "رَبَّنَا إِنَّنَا",
    "بِنِعْمَتِهِ إِخْوَانًا",
    "وَمَا أَرْسَلْنَا",
    "مِنْ أَنْصَارِيَ إِلَى اللَّهِ"
]]

Madd_Al_Laazim_words_1 = [(w, w) for w in [
    "لَا تُنظِرْ",
    "حَاجَّةٌ",
    "مُدْهَامَّتَانِ",
    "صَّافَّاتِ",
    "كُلُّ دَابَّةٍ",
    "ٱلْحَاقَّةُ",
    "بِضَارِبَيْنِ",
    "وَخَلَقَ ٱلْجَانَّ",
    "وَلَا ٱلضَّآلِّينَ"
]]

Madd_Al_Laazim_words_2 = [(w, w) for w in [
    "ءَآلْـٰٔنَ"
]]

Madd_Al_Laazim_words_3 = [(w, w) for w in [
    "ٱلۤـمّۤ = ٱلـمّ",
    "يٰسٓ = يـس",
    "نٓ = ن",
    "قٓ = ق",
    "صٓ = ص"
]]

Madd_Al_Aarid_words_1 = [(w, w) for w in [
    "يَعْمَهُونَ",
    "ٱلْمُسْتَقِيمَ",
    "ٱلْعَٰلَمِينَ",
    "يَشْعُرُونَ"
]]

Madd_Al_Aarid_words_2 = [(w, w) for w in [
    "وَإِيَّايَ فَارْهَبُونِ",
    "يَوْمِ ٱلدِّينِ",
    "وَإِيَّايَ فَاتَّقُونِ"
]]

Madd_Al_Aarid_words_3 = [(w, w) for w in [
    "تَوَّابُ ٱلرَّحِيمُ",
    "نَسْتَعِينُ",
    "عَذَابٌ مُّهِينٌ"
]]

Madd_Al_Leen_words = [(w, w) for w in [
    "وَٱلصَّيْفِ",
    "وَلَا نَوْمٍ",
    "مِنْ خَوْفٍ",
    "ٱلْبَيْتِ",
    "عَلَيْهِ",
    "إِلَيْهِ",
    "خَيْرٌ",
    "مِنَ ٱلنَّوْمِ",
    "نُعَلِّمُكَ",
    "شَيْءٍ",
    "قُرَيْشٍ",
    "عَيْنٍ"
]]

Izhaar_words = [(w, w) for w in [
    "وَمَنْ خَلَقْنَا",
    "فَلَهُمْ أَجْرٌ غَيْرُ مَمْنُونٍ",
    "كَاذِبَةٍ خَاطِئَةٍ",
    "لَطِيفٌ خَبِيرٌ",
    "مِنْ حَيْثُ",
    "عَذَابٌ عَظِيمٌ",
    "مِنْ هَاجَرَ",
    "وَأَنْ عَسَى",
    "تَحْتِهَا الْأَنْهَارُ"
]]

Ikhfa_words = [(w, w) for w in [
    "إِن كُنتُم",
    "وَكُنتُم",
    "غَنِيٌّ كَرِيمٌ",
    "وَلِيًّا فَاطِرَ السَّمَاوَاتِ",
    "جَنَّاتٍ تَجْرِي",
    "فَمَنْ فَرَضَ",
    "وَأَجْرٌ كَبِيرٌ",
    "أَنفُسَهُمْ",
    "وَلَهُمْ عَذَابٌ شَدِيدٌ",
    "عَنْ سَبِيلِهِ",
    "شَيْءٍ قَدِيرٌ",
    "عَنْ صَلَاتِهِمْ"
]]

Iqlaab_words = [(w, w) for w in [
    "مِن بَعْدِهَا",
    "وَأَنبَتْنَا",
    "سَمِيعٌ بَصِيرٌ",
    "بِذِنبِهِمْ",
    "مِن بَحِيرَةٍ",
    "سَوَاءٌ بَيْنَنَا",
    "أَنبَئْهُم بِأَسْمَائِهِمْ",
    "شَهِيدًا بَيْنَنَا",
    "يُومَئِذٍ بِجَهَنَّمَ",
    "عَتَلٍّ بَعْدَ",
    "زَوْجٌ بَهِيجٌ"
]]

Idghaam_words_1 = [(w, w) for w in [
    "وَمَنْ يَعْمَلْ",
    "شَيْءٍ وَهُمْ",
    "خَيْرًا يُرَهُ",
    "سِرًّا وَجَهْرًا",
    "وَمِنْ مَاءٍ",
    "فَضْلًا مِّنَ اللَّهِ",
    "يَٰمَن يَزِيدُ",
    "عَدْنٍ يَدْخُلُونَ",
    "مِّن نَّارٍ"
]]

Idghaam_words_2 = [(w, w) for w in [
    "مِن لَّدُنْهُ",
    "يَـمَنْ لَا يَحُولُ",
    "غَفُورٌ رَّحِيمٌ",
    "أَشْهَدُ أَنْ لَا إِلٰهَ إِلَّا اللَّهُ",
    "رَحْمَةً لِّلْمُؤْمِنِينَ",
    "مِن رِّزْقِهِ",
    "مِن رَّبِّهِمْ",
    "وَيْلٌ لِّكُلِّ",
    "رِزْقًا لِّلْعِبَادِ"
]]

Idghaam_Mithlain_words_1 = [(w, w) for w in [
    "بَلْ لَجَوْا",
    "رَبِحَتْ تِجَارَتُهُمْ",
    "أَقِلْ لَكْ",
    "يُدْرِككُمُ الْمَوْتُ",
    "وَقَدْ دَخَلُوا",
    "بِمَا عَصَوْا وَكَانُوا",
    "إِذْ ذَهَبَ",
    "ٱتَّهُم مِّن فَضْلِهِ",
    "ٱذْهَبْ بِكِتَابِي",
    "ٱضْرِبْ بِعَصَاكَ",
    "لَمْ تَسْتَطِعْ عَلَيْهِ",
    "وَٱذْكُر رَّبَّكَ"
]]

Idghaam_Mithlain_Ghunnah_words = [(w, w) for w in [
    "كَمْ مِنْ فِئَةٍ",
    "عَلَيْكُمْ مُّصَدَّقَةٌ",
    "مِنْ نَارٍ",
    "مِنْ نَفْسٍ",
    "أَنفُسَهُم مِّن",
    "عَلَيْكُم مِّنْ خَيْرٍ",
    "أَن نَّاكُلَ",
    "وَمَن نُّعَمِّرْهُ",
    "أَنَّهُمْ مُّلَاقُوا",
    "بِهِم مِّنَ السَّمَاءِ",
    "مِنْكُمْ مِّن نِّسَائِهِمْ",
    "أَن نَّعْبُدَ"
]]

Qalqalah_words = [(w, w) for w in [
    "نَطْمِسْ",
    "تَقْتُلْ",
    "أَلَّا يَجْعَلَ",
    "صَبْرَهُ",
    "إِبْرَاهِيمَ",
    "وَاقْتَرِبْ",
    "فَقَدْ",
    "تَجْرِهُ",
    "تَقْرِضُهُمْ",
    "صَدْرَكْ",
    "قَبْلَهُمْ",
    "يَدْخُلُونَ"
]]

Saktah_words = [(w, w) for w in [
    "لَهُ عِوَجًا - قَيِّمًا لِيُنذِرَ",
    "مَرْقَدِنَا - هَذَا",
    "وَقِيلَ مَنْ - رَاقٍ",
    "كَلَّا بَلْ - رَانَ"
]]

# ── Pre‐generate all TTS audio ─────────────────────────────
def pregenerate(pairs):
    for token, _ in pairs:
        out = os.path.join(AUDIO_DIR, f"{token}.wav")
        if not os.path.isfile(out):
            wav = tts.tts(text=token, language="ar", speaker_wav=REF_PATH)
            sr  = tts.synthesizer.tts_config["audio"]["output_sample_rate"]
            sf.write(out, wav, sr)

pregenerate(letters)
pregenerate(fathah_words)
pregenerate(kasra_words)
pregenerate(dammah_words)
pregenerate(jazm_or_sukoon_words)
pregenerate(Madd_Letter_Alif_words)
pregenerate(Madd_Letter_Yaa_words)
pregenerate(Madd_Letter_Waaw_words)
pregenerate(Tanveen_words)
pregenerate(Shadda_words)
pregenerate(Moon_And_Sun_Lee_words)
pregenerate(Lafzatullah_words)
pregenerate(Al_Madd_al_Tabee_words)
pregenerate(Madd_Al_Muttasil_words)
pregenerate(Madd_Al_Munfasil_words)
pregenerate(Madd_Al_Laazim_words_1)
pregenerate(Madd_Al_Laazim_words_2)
pregenerate(Madd_Al_Laazim_words_3)
pregenerate(Madd_Al_Aarid_words_1)
pregenerate(Madd_Al_Aarid_words_2)
pregenerate(Madd_Al_Aarid_words_3)
pregenerate(Madd_Al_Leen_words)
pregenerate(Izhaar_words)
pregenerate(Ikhfa_words)
pregenerate(Iqlaab_words)
pregenerate(Idghaam_words_1)
pregenerate(Idghaam_words_2)
pregenerate(Idghaam_Mithlain_words_1)
pregenerate(Idghaam_Mithlain_Ghunnah_words)
pregenerate(Qalqalah_words)
pregenerate(Saktah_words)

# ── Load reference audios into memory for recognition ──────
ref_audios = {}
for fn in os.listdir(AUDIO_DIR):
    if fn.endswith('.wav'):
        arr, _ = librosa.load(os.path.join(AUDIO_DIR, fn), sr=16000)
        ref_audios[fn] = arr

# ── Flask Routes ───────────────────────────────────────────
# Main Page 

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/Taleem')
def taleem():
    return render_template('taleem.html')

@app.route('/Quiz')
def quiz():
    return render_template('quiz.html')

@app.route('/Tajweed')
def tajweed():
    return render_template('tajweed.html')

#Taleem Options

@app.route('/Taleem/letters')
def letters_page():
    return render_template('Taleem/letters.html', letters=letters)

@app.route('/Taleem/fathah')
def fathah_page():
    return render_template('Taleem/fathah.html', fathah_words=fathah_words)

@app.route('/Taleem/kasrah')
def kasrah_page():
    return render_template('Taleem/kasrah.html', kasra_words=kasra_words)

@app.route('/Taleem/dammah')
def dammah_page():
    return render_template('Taleem/dammah.html', dammah_words=dammah_words)

@app.route('/Taleem/Jazm_or_Sukoon')
def Jazm_or_Sukoon_page():
    return render_template('Taleem/Jazm_or_Sukoon.html', jazm_or_sukoon_words=jazm_or_sukoon_words)

@app.route('/Taleem/Madd_Letter_Alif')
def Madd_Letter_Alif_page():
    return render_template('Taleem/Madd_Letter_Alif.html', Madd_Letter_Alif_words=Madd_Letter_Alif_words)

@app.route('/Taleem/Madd_Letter_Yaa')
def Madd_Letter_Yaa_page():
    return render_template('Taleem/Madd_Letter_Yaa.html', Madd_Letter_Yaa_words=Madd_Letter_Yaa_words)

@app.route('/Taleem/Madd_Letter_Waaw')
def Madd_Letter_Waaw_page():
    return render_template('Taleem/Madd_Letter_Waaw.html', Madd_Letter_Waaw_words=Madd_Letter_Waaw_words)

@app.route('/Taleem/Tanveen')
def Tanveen_page():
    return render_template('Taleem/Tanveen.html', Tanveen_words=Tanveen_words)

@app.route('/Taleem/Shadda')
def Shadda_page():
    return render_template('Taleem/Shadda.html', Shadda_words=Shadda_words)

@app.route('/Taleem/Moon_And_Sun_Lee')
def Moon_And_Sun_Lee_page():
    return render_template('Taleem/Moon_And_Sun_Lee.html', Moon_And_Sun_Lee_words=Moon_And_Sun_Lee_words)

@app.route('/Taleem/Lafzatullah')
def Lafzatullah_page():
    return render_template('Taleem/Lafzatullah.html', Lafzatullah_words=Lafzatullah_words)



# Tajweed Section:


@app.route('/Tajweed/introduction')
def introduction_page():
    return render_template('/Tajweed/introduction.html')

@app.route('/Tajweed/Al_Madd_al_Tabee')
def Al_Madd_al_Tabee_page():
    return render_template('/Tajweed/Al_Madd_al_Tabee.html', Al_Madd_al_Tabee_words=Al_Madd_al_Tabee_words)

@app.route('/Tajweed/Madd_Al_Muttasil')
def Madd_Al_Muttasil_page():
    return render_template('/Tajweed/Madd_Al_Muttasil.html', Madd_Al_Muttasil_words=Madd_Al_Muttasil_words)

@app.route('/Tajweed/Madd_Al_Munfasil')
def Madd_Al_Munfasil_page():
    return render_template('/Tajweed/Madd_Al_Munfasil.html', Madd_Al_Munfasil_words=Madd_Al_Munfasil_words)

@app.route('/Tajweed/Madd_Al_Laazim')
def Madd_Al_Laazim_page():
    return render_template('/Tajweed/Madd_Al_Laazim.html', Madd_Al_Laazim_words_1=Madd_Al_Laazim_words_1, Madd_Al_Laazim_words_2=Madd_Al_Laazim_words_2, Madd_Al_Laazim_words_3=Madd_Al_Laazim_words_3)

@app.route('/Tajweed/Madd_Al_Aarid')
def Madd_Al_Aarid_page():
    return render_template('/Tajweed/Madd_Al_Aarid.html', Madd_Al_Aarid_words_1=Madd_Al_Aarid_words_1, Madd_Al_Aarid_words_2=Madd_Al_Aarid_words_2, Madd_Al_Aarid_words_3=Madd_Al_Aarid_words_3)

@app.route('/Tajweed/Madd_Al_Leen')
def Madd_Al_Leen_page():
    return render_template('/Tajweed/Madd_Al_Leen.html', Madd_Al_Leen_words=Madd_Al_Leen_words)

@app.route('/Tajweed/Introduction_to_Tanveen')
def Introduction_to_Tanveen_page():
    return render_template('/Tajweed/Introduction_to_Tanveen.html')

@app.route('/Tajweed/Ithhar')
def Ithhar_page():
    return render_template('/Tajweed/Ithhar.html', Izhaar_words=Izhaar_words)

@app.route('/Tajweed/Al_Ikhfaa')
def Al_Ikhfaa_page():
    return render_template('/Tajweed/Al_Ikhfaa.html', Ikhfa_words=Ikhfa_words)

@app.route('/Tajweed/Al_Iqlaab')
def Al_Iqlaab_page():
    return render_template('/Tajweed/Al_Iqlaab.html', Iqlaab_words=Iqlaab_words)

@app.route('/Tajweed/Al_Idghaam')
def Al_Idghaam_page():
    return render_template('/Tajweed/Al_Idghaam.html', Idghaam_words_1=Idghaam_words_1, Idghaam_words_2=Idghaam_words_2)

@app.route('/Tajweed/Idghaam_Mithlain')
def Idghaam_Mithlain_page():
    return render_template('/Tajweed/Idghaam_Mithlain.html', Idghaam_Mithlain_words_1=Idghaam_Mithlain_words_1, Idghaam_Mithlain_Ghunnah_words=Idghaam_Mithlain_Ghunnah_words)

@app.route('/Tajweed/Qalqalah')
def Qalqalah_page():
    return render_template('/Tajweed/Qalqalah.html', Qalqalah_words=Qalqalah_words)

@app.route('/Tajweed/Saktah')
def Saktah_page():
    return render_template('/Tajweed/Saktah.html', Saktah_words=Saktah_words)







# ── Quiz Options ───────────────────────────────────────────
@app.route('/Quiz/quiz_letters')
def quiz_letters():
    return render_template('Quiz/quiz_letters.html', letters=letters)

@app.route('/Quiz/quiz_fathah')
def quiz_fathah():
    return render_template('Quiz/quiz_fathah.html', fathah_words=fathah_words)

@app.route('/Quiz/quiz_kasrah')
def quiz_kasrah():
    return render_template('Quiz/quiz_kasrah.html', kasra_words=kasra_words)

@app.route('/Quiz/quiz_dammah')
def quiz_dammah():
    return render_template('Quiz/quiz_dammah.html', dammah_words=dammah_words)

@app.route('/Quiz/quiz_Jazm_or_Sukoon')
def quiz_Jazm_or_Sukoon():
    return render_template('Quiz/quiz_Jazm_or_Sukoon.html', jazm_or_sukoon_words=jazm_or_sukoon_words)

@app.route('/Quiz/quiz_Madd_Letter_Alif')
def quiz_Madd_Letter_Alif():
    return render_template('Quiz/quiz_Madd_Letter_Alif.html', Madd_Letter_Alif_words=Madd_Letter_Alif_words)

@app.route('/Quiz/quiz_Madd_Letter_Yaa')
def quiz_Madd_Letter_Yaa():
    return render_template('Quiz/quiz_Madd_Letter_Yaa.html', Madd_Letter_Yaa_words=Madd_Letter_Yaa_words)

@app.route('/Quiz/quiz_Madd_Letter_Waaw')
def quiz_Madd_Letter_Waaw():
    return render_template('Quiz/quiz_Madd_Letter_Waaw.html', Madd_Letter_Waaw_words=Madd_Letter_Waaw_words)

@app.route('/Quiz/quiz_Tanveen')
def quiz_Tanveen():
    return render_template('Quiz/quiz_Tanveen.html', Tanveen_words=Tanveen_words)

@app.route('/Quiz/quiz_Shadda')
def quiz_Shadda():
    return render_template('Quiz/quiz_Shadda.html', Shadda_words=Shadda_words)

@app.route('/Quiz/quiz_Moon_And_Sun_Lee')
def quiz_Moon_And_Sun_Lee():
    return render_template('Quiz/quiz_Moon_And_Sun_Lee.html', Moon_And_Sun_Lee_words=Moon_And_Sun_Lee_words)

@app.route('/Quiz/quiz_Lafzatullah')
def quiz_Lafzatullah():
    return render_template('Quiz/quiz_Lafzatullah.html', Lafzatullah_words=Lafzatullah_words)


@app.route('/tts')
def tts_endpoint():
    token = request.args.get('char','')
    path  = os.path.join(AUDIO_DIR, f"{token}.wav")
    if not os.path.isfile(path):
        return "Not found", 404
    return send_file(path, mimetype='audio/wav')

@app.route('/recognize', methods=['POST'])
def recognize():
    uploaded = request.files.get('file') or request.files.get('audio')
    if not uploaded:
        return jsonify(error="No audio provided"), 400

    tmp = os.path.join(BASE_DIR, 'user_input.wav')
    uploaded.save(tmp)
    user_audio, _ = librosa.load(tmp, sr=16000)

    best_score, best_name = max(
        (
            (
                np.corrcoef(
                    user_audio[:min(len(user_audio), len(ref_audios[fn]))],
                    ref_audios[fn][:min(len(user_audio), len(ref_audios[fn]))]
                )[0,1],
                fn
            )
            for fn in ref_audios
        ),
        key=lambda x: x[0]
    )

    score = max(int(best_score*100), 0)
    if score >= 50:
        fb_text = f"آپ نے {score}% درست پڑھا ہے۔ بہت خوب!"
        fb_file = "feedback_high.wav"
    elif score >= 30:
        fb_text = f"آپ نے {score}% درست پڑھا ہے، بہتر کریں۔"
        fb_file = "feedback_medium.wav"
    else:
        fb_text = f"آپ نے صرف {score}% درست پڑھا ہے، دوبارہ کریں۔"
        fb_file = "feedback_low.wav"

    return jsonify(
        accuracy=score,
        feedback=fb_text,
        audio_url=f"/static/audio/{fb_file}"
    )

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
