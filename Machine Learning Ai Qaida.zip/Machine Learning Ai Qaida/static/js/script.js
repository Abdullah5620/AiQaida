function playLetter(char) {
  const audio = new Audio(`/tts?char=${encodeURIComponent(char)}`);
  audio.play();
}
